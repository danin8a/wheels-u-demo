import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import {
  Search,
  MapPin,
  ArrowUpDown,
  Filter,
  PlusCircle,
  Clock,
  Users,
  ShieldCheck,
  Car,
  ChevronRight,
  Info,
} from 'lucide-react-native';
import { WheelsULogo } from '../../src/components/brand/WheelsULogo';
import { Button } from '../../src/components/ui/Button';
import { Card } from '../../src/components/ui/Card';
import { Badge } from '../../src/components/ui/Badge';
import { COLORS, FONTS, RADIUS, SPACING } from '../../src/constants/theme';
import { useTripsStore, FilterType } from '../../src/stores/useTripsStore';
import { useAuthStore } from '../../src/stores/useAuthStore';
import { Trip } from '../../src/types';

const FILTERS: { key: FilterType; label: string }[] = [
  { key: 'Todos', label: 'Todos' },
  { key: 'Hoy', label: 'Hoy' },
  { key: 'Mañana', label: 'Mañana' },
  { key: 'Regreso', label: 'Regreso' },
  { key: 'Moto', label: 'Moto' },
];

export default function SearchTripsScreen() {
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const {
    filteredTrips,
    activeFilter,
    setActiveFilter,
    searchOrigen,
    searchDestino,
    setSearchOrigen,
    setSearchDestino,
    requestSeat,
  } = useTripsStore();

  const [bookingSuccessModal, setBookingSuccessModal] = useState<string | null>(null);

  const handleSwapAddresses = () => {
    const currentOrigen = searchOrigen;
    setSearchOrigen(searchDestino || '[TU UNIVERSIDAD]');
    setSearchDestino(currentOrigen || '[TU BARRIO]');
  };

  const handleTripPress = (tripId: string) => {
    router.push({
      pathname: '/viaje/[id]',
      params: { id: tripId },
    });
  };

  const handleQuickRequest = (trip: Trip, e: any) => {
    e.stopPropagation?.();
    const result = requestSeat(
      trip.id,
      user?.id || 'usr-current',
      user?.nombre || '[TU NOMBRE]',
      '¡Hola! Me gustaría ocupar uno de los cupos.'
    );

    if (result.success) {
      setBookingSuccessModal(result.message);
    } else {
      Alert.alert('Aviso', result.message);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Cabecera superior con Logo y Acción rápida */}
        <View style={styles.header}>
          <WheelsULogo size={36} showText textColor={COLORS.navy} />
          <TouchableOpacity
            style={styles.offerBadge}
            onPress={() => router.push('/viaje/nuevo')}
            activeOpacity={0.8}
          >
            <PlusCircle size={16} color={COLORS.navy} />
            <Text style={styles.offerBadgeText}>Ofrecer viaje</Text>
          </TouchableOpacity>
        </View>

        {/* Saludo y subtítulo */}
        <View style={styles.greetingSection}>
          <Text style={styles.greetingTitle}>
            ¿A dónde vas hoy, <Text style={styles.studentName}>{user?.nombre || '[TU NOMBRE]'}</Text>?
          </Text>
          <Text style={styles.greetingSubtitle}>
            Muévete seguro con estudiantes de tu campus.
          </Text>
        </View>

        {/* Tarjeta de Búsqueda de alto contraste */}
        <Card variant="navy" style={styles.searchCard}>
          <View style={styles.inputGroup}>
            <View style={styles.inputRow}>
              <View style={styles.originDot} />
              <TextInput
                style={styles.textInput}
                placeholder="Desde: [TU BARRIO o parada]"
                placeholderTextColor="#A3B8D8"
                value={searchOrigen}
                onChangeText={setSearchOrigen}
              />
            </View>

            <View style={styles.dividerRow}>
              <View style={styles.dottedDivider} />
              <TouchableOpacity
                onPress={handleSwapAddresses}
                style={styles.swapButton}
                activeOpacity={0.7}
              >
                <ArrowUpDown size={16} color={COLORS.navy} />
              </TouchableOpacity>
            </View>

            <View style={styles.inputRow}>
              <MapPin size={18} color={COLORS.primary} style={styles.destinationPin} />
              <TextInput
                style={styles.textInput}
                placeholder="Hacia: [TU UNIVERSIDAD]"
                placeholderTextColor="#A3B8D8"
                value={searchDestino}
                onChangeText={setSearchDestino}
              />
            </View>
          </View>
        </Card>

        {/* Aviso de no lucro */}
        <View style={styles.nonProfitBanner}>
          <Info size={14} color={COLORS.support} />
          <Text style={styles.nonProfitBannerText}>
            Aportes únicamente para cubrir gastos de combustible y peajes.
          </Text>
        </View>

        {/* Píldoras de Filtro (Hoy, Mañana, Regreso, Moto) */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterScroll}
        >
          {FILTERS.map((f) => {
            const isSelected = activeFilter === f.key;
            return (
              <TouchableOpacity
                key={f.key}
                onPress={() => setActiveFilter(f.key)}
                style={[
                  styles.filterPill,
                  isSelected && styles.filterPillActive,
                ]}
                activeOpacity={0.8}
              >
                <Text
                  style={[
                    styles.filterPillText,
                    isSelected && styles.filterPillTextActive,
                  ]}
                >
                  {f.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Listado de viajes disponibles */}
        <View style={styles.listSection}>
          <View style={styles.listHeaderRow}>
            <Text style={styles.sectionTitle}>
              Viajes disponibles ({filteredTrips.length})
            </Text>
            <Text style={styles.universityBadge}>{user?.universidad_id ? '[TU UNIVERSIDAD]' : 'Campus'}</Text>
          </View>

          {filteredTrips.length === 0 ? (
            /* Estado vacío */
            <Card style={styles.emptyCard}>
              <Car size={40} color={COLORS.support} style={{ marginBottom: 10 }} />
              <Text style={styles.emptyTitle}>No hay viajes con este filtro</Text>
              <Text style={styles.emptySubtitle}>
                Sé el primero en ofrecer un viaje desde esta zona o intenta cambiar el origen/destino.
              </Text>
              <Button
                title="Publicar esta ruta"
                variant="yellow"
                size="sm"
                onPress={() => router.push('/viaje/nuevo')}
                style={{ marginTop: 12 }}
              />
            </Card>
          ) : (
            filteredTrips.map((trip) => {
              const hasAvailableSeats = trip.cupos_disponibles > 0;
              return (
                <TouchableOpacity
                  key={trip.id}
                  activeOpacity={0.9}
                  onPress={() => handleTripPress(trip.id)}
                  style={styles.tripCardWrapper}
                >
                  <Card style={styles.tripCard}>
                    {/* Fila Conductor y Hora */}
                    <View style={styles.tripTopRow}>
                      <View style={styles.driverInfo}>
                        <View style={styles.driverAvatar}>
                          <Text style={styles.driverAvatarText}>
                            {trip.conductor.nombre.slice(0, 2).toUpperCase()}
                          </Text>
                        </View>
                        <View>
                          <View style={styles.driverNameRow}>
                            <Text style={styles.driverName}>{trip.conductor.nombre}</Text>
                            {trip.conductor.verificado && (
                              <ShieldCheck size={14} color={COLORS.navy} style={{ marginLeft: 4 }} />
                            )}
                          </View>
                          <Text style={styles.driverCareer}>
                            {trip.conductor.carrera} • {trip.conductor.semestre}.° sem
                          </Text>
                        </View>
                      </View>

                      {/* Tarjeta de Hora grande */}
                      <View style={styles.timeBadge}>
                        <Clock size={12} color={COLORS.navy} style={{ marginRight: 3 }} />
                        <Text style={styles.timeText}>{trip.hora_salida}</Text>
                      </View>
                    </View>

                    {/* Trayecto Origen -> Destino */}
                    <View style={styles.routeContainer}>
                      <View style={styles.routePill}>
                        <Text style={styles.routeText} numberOfLines={1}>
                          {trip.origen} → {trip.destino}
                        </Text>
                      </View>
                    </View>

                    {/* Paradas intermedias preview */}
                    {trip.paradas && trip.paradas.length > 0 && (
                      <Text style={styles.stopsPreview}>
                        📍 {trip.paradas.length} paradas intermedias programadas
                      </Text>
                    )}

                    {/* Fila Inferior: Cupos, Aporte y Botón "Pedir cupo" */}
                    <View style={styles.tripBottomRow}>
                      <View style={styles.bottomMeta}>
                        <Text
                          style={[
                            styles.seatsText,
                            !hasAvailableSeats && styles.seatsFullText,
                          ]}
                        >
                          {hasAvailableSeats
                            ? `${trip.cupos_disponibles} cupo${trip.cupos_disponibles > 1 ? 's' : ''} libre${trip.cupos_disponibles > 1 ? 's' : ''}`
                            : 'Cupos agotados'}
                        </Text>
                        <Text style={styles.aporteText}>
                          $ {trip.aporte.toLocaleString('es-CO')}
                          <Text style={styles.aporteSub}> / aporte</Text>
                        </Text>
                      </View>

                      <Button
                        title={hasAvailableSeats ? 'Pedir cupo' : 'Lleno'}
                        variant={hasAvailableSeats ? 'primary' : 'outline'}
                        size="sm"
                        disabled={!hasAvailableSeats}
                        onPress={(e) => handleQuickRequest(trip, e)}
                        style={styles.requestBtn}
                      />
                    </View>
                  </Card>
                </TouchableOpacity>
              );
            })
          )}
        </View>

        {/* Modal de confirmación rápida */}
        {bookingSuccessModal && (
          <View style={styles.modalOverlay}>
            <Card variant="white" style={styles.modalCard}>
              <ShieldCheck size={48} color={COLORS.navy} style={{ alignSelf: 'center', marginBottom: 12 }} />
              <Text style={styles.modalTitle}>¡Solicitud Exitosa!</Text>
              <Text style={styles.modalBody}>{bookingSuccessModal}</Text>
              <Button
                title="Ir al Chat del Viaje"
                variant="primary"
                onPress={() => {
                  setBookingSuccessModal(null);
                  router.push('/chat/trip-1');
                }}
                style={{ marginTop: 16 }}
              />
              <Button
                title="Cerrar"
                variant="ghost"
                onPress={() => setBookingSuccessModal(null)}
                style={{ marginTop: 8 }}
              />
            </Card>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.md,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.lg,
  },
  offerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: RADIUS.pill,
    borderWidth: 1,
    borderColor: COLORS.navy,
  },
  offerBadgeText: {
    fontFamily: FONTS.family,
    color: COLORS.navy,
    fontWeight: '700',
    fontSize: FONTS.sizes.xs,
    marginLeft: 6,
  },
  greetingSection: {
    marginBottom: SPACING.lg,
  },
  greetingTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xxl,
    fontWeight: '700',
    color: COLORS.navy,
    letterSpacing: -0.5,
  },
  studentName: {
    color: COLORS.navy,
    textDecorationLine: 'underline',
  },
  greetingSubtitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    color: COLORS.support,
    marginTop: 4,
  },
  searchCard: {
    padding: SPACING.lg,
    borderRadius: RADIUS.card,
    marginBottom: SPACING.sm,
  },
  inputGroup: {
    width: '100%',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  originDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.primary,
    marginRight: 10,
  },
  destinationPin: {
    marginRight: 8,
  },
  textInput: {
    flex: 1,
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    color: '#FFFFFF',
    paddingVertical: 8,
    minHeight: 44,
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 5,
    marginVertical: 4,
  },
  dottedDivider: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  swapButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  nonProfitBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EAF0FA',
    paddingHorizontal: SPACING.md,
    paddingVertical: 6,
    borderRadius: RADIUS.md,
    marginBottom: SPACING.md,
  },
  nonProfitBannerText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    marginLeft: 6,
    flex: 1,
  },
  filterScroll: {
    paddingBottom: SPACING.md,
    gap: 8,
  },
  filterPill: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: RADIUS.pill,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#DFE5F0',
    minHeight: 38,
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterPillActive: {
    backgroundColor: COLORS.navy,
    borderColor: COLORS.navy,
  },
  filterPillText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    fontWeight: '600',
    color: COLORS.support,
  },
  filterPillTextActive: {
    color: '#FFFFFF',
  },
  listSection: {
    marginTop: SPACING.sm,
  },
  listHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  sectionTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.lg,
    fontWeight: '700',
    color: COLORS.navy,
  },
  universityBadge: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    fontWeight: '600',
    color: COLORS.support,
    backgroundColor: '#E5EBF5',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: RADIUS.pill,
  },
  tripCardWrapper: {
    marginBottom: SPACING.md,
  },
  tripCard: {
    padding: SPACING.md + 2,
    borderRadius: RADIUS.card,
  },
  tripTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.primary,
    borderWidth: 1.5,
    borderColor: COLORS.navy,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  driverAvatarText: {
    fontFamily: FONTS.family,
    color: COLORS.navy,
    fontWeight: '700',
    fontSize: FONTS.sizes.sm,
  },
  driverNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverName: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    fontWeight: '700',
    color: COLORS.navy,
  },
  driverCareer: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    marginTop: 2,
  },
  timeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F6FC',
    borderWidth: 1,
    borderColor: '#D4DEEE',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: RADIUS.md,
  },
  timeText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    fontWeight: '700',
    color: COLORS.navy,
  },
  routeContainer: {
    marginVertical: 6,
  },
  routePill: {
    backgroundColor: '#F8FAFD',
    borderWidth: 1,
    borderColor: '#E8EDF5',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: RADIUS.md,
  },
  routeText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    fontWeight: '600',
    color: COLORS.navy,
  },
  stopsPreview: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    marginBottom: 8,
  },
  tripBottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SPACING.xs,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#F0F3F8',
  },
  bottomMeta: {
    flex: 1,
  },
  seatsText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    fontWeight: '700',
    color: COLORS.success,
  },
  seatsFullText: {
    color: COLORS.danger,
  },
  aporteText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    fontWeight: '700',
    color: COLORS.navy,
    marginTop: 2,
  },
  aporteSub: {
    fontSize: FONTS.sizes.xs,
    fontWeight: '400',
    color: COLORS.support,
  },
  requestBtn: {
    minHeight: 40,
    paddingHorizontal: 16,
    borderRadius: RADIUS.pill,
  },
  emptyCard: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.xxl,
  },
  emptyTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    fontWeight: '700',
    color: COLORS.navy,
  },
  emptySubtitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    textAlign: 'center',
    marginTop: 4,
    maxWidth: 260,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(14, 42, 94, 0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: SPACING.xl,
    zIndex: 999,
  },
  modalCard: {
    width: '100%',
    maxWidth: 340,
    alignItems: 'center',
    padding: SPACING.xl,
    borderRadius: RADIUS.xl,
  },
  modalTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.lg,
    fontWeight: '700',
    color: COLORS.navy,
  },
  modalBody: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    color: COLORS.support,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 20,
  },
});
