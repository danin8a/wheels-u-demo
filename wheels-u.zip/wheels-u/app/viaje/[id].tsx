import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  ChevronLeft,
  Clock,
  MapPin,
  ShieldCheck,
  Users,
  Car,
  MessageCircle,
  Share2,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react-native';
import { WheelsULogo } from '../../src/components/brand/WheelsULogo';
import { Button } from '../../src/components/ui/Button';
import { Card } from '../../src/components/ui/Card';
import { Badge } from '../../src/components/ui/Badge';
import { COLORS, FONTS, RADIUS, SPACING } from '../../src/constants/theme';
import { useTripsStore } from '../../src/stores/useTripsStore';
import { useAuthStore } from '../../src/stores/useAuthStore';

export default function TripDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const user = useAuthStore((s) => s.user);
  const getTripById = useTripsStore((s) => s.getTripById);
  const requestSeat = useTripsStore((s) => s.requestSeat);

  const trip = getTripById(id || 'trip-1');
  const [requested, setRequested] = useState(false);

  if (!trip) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorTitle}>Viaje no encontrado</Text>
          <Button title="Volver al buscador" onPress={() => router.back()} />
        </View>
      </SafeAreaView>
    );
  }

  const hasSeats = trip.cupos_disponibles > 0;

  const handleRequestSeat = () => {
    const res = requestSeat(
      trip.id,
      user?.id || 'usr-current',
      user?.nombre || '[TU NOMBRE]',
      '¡Hola! Solicito un cupo en tu ruta.'
    );

    if (res.success) {
      setRequested(true);
      Alert.alert(
        '¡Cupo Solicitado!',
        `Has reservado tu lugar con ${trip.conductor.nombre}. Ahora puedes coordinar los detalles en el chat.`,
        [
          {
            text: 'Ir al Chat',
            onPress: () => router.push({ pathname: '/chat/[id]', params: { id: trip.id } }),
          },
          { text: 'Aceptar', style: 'cancel' },
        ]
      );
    } else {
      Alert.alert('No fue posible reservar', res.message);
    }
  };

  const handleChatPress = () => {
    router.push({
      pathname: '/chat/[id]',
      params: { id: trip.id },
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Cabecera */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}
            activeOpacity={0.7}
          >
            <ChevronLeft size={24} color={COLORS.navy} />
            <Text style={styles.backText}>Volver</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Tu próxima ruta</Text>
          <WheelsULogo size={32} />
        </View>

        {/* Tarjeta Principal del Conductor (Estilo Azul Marino del Mockup) */}
        <Card variant="navy" style={styles.heroCard}>
          <View style={styles.driverSection}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverAvatarText}>
                {trip.conductor.nombre.slice(0, 2).toUpperCase()}
              </Text>
            </View>

            <View style={styles.driverInfo}>
              <View style={styles.driverNameRow}>
                <Text style={styles.driverName}>{trip.conductor.nombre}</Text>
                {trip.conductor.verificado && (
                  <ShieldCheck size={18} color={COLORS.primary} style={{ marginLeft: 6 }} />
                )}
              </View>
              <Text style={styles.driverSub}>
                {trip.conductor.carrera} • {trip.conductor.semestre}.° semestre • Estudiante verificado
              </Text>
            </View>
          </View>

          {/* Resumen del trayecto */}
          <View style={styles.tripSummaryBox}>
            <Text style={styles.tripSummaryText}>
              Sale a las {trip.hora_salida} desde {trip.origen} • {trip.paradas.length} paradas • Llega aprox. {trip.hora_llegada_estimada || '07:20'}
            </Text>
            <Text style={styles.aporteNotice}>
              Aporte: $ {trip.aporte.toLocaleString('es-CO')} [POR PERSONA]
            </Text>
          </View>

          {/* Etiquetas / Tags de Convivencia */}
          <View style={styles.tagsContainer}>
            {(trip.conductor.etiquetas || ['Puntual', 'Música suave', 'Sin fumar']).map(
              (tag, idx) => (
                <View key={idx} style={styles.tagPill}>
                  <Text style={styles.tagText}>{tag}</Text>
                </View>
              )
            )}
          </View>
        </Card>

        {/* Itinerario y Paradas Programadas */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recorrido y Paradas</Text>
          <Card style={styles.stopsCard}>
            {trip.paradas.map((stop, index) => {
              const isFirst = index === 0;
              const isLast = index === trip.paradas.length - 1;
              return (
                <View key={stop.id} style={styles.stopItem}>
                  <View style={styles.stopTimeline}>
                    <View
                      style={[
                        styles.stopDot,
                        isFirst && styles.stopDotStart,
                        isLast && styles.stopDotEnd,
                      ]}
                    />
                    {!isLast && <View style={styles.stopLine} />}
                  </View>
                  <View style={styles.stopContent}>
                    <View style={styles.stopHeader}>
                      <Text style={styles.stopName}>{stop.nombre}</Text>
                      <Text style={styles.stopTime}>{stop.hora_estimada}</Text>
                    </View>
                    <Text style={styles.stopOrder}>
                      {isFirst ? 'Punto de partida' : isLast ? 'Llegada al campus' : `Parada ${index + 1}`}
                    </Text>
                  </View>
                </View>
              );
            })}
          </Card>
        </View>

        {/* Pasajeros Confirmados y Cupos */}
        <View style={styles.section}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>Pasajeros en este viaje</Text>
            <Badge
              label={`${trip.cupos_disponibles} cupo${trip.cupos_disponibles !== 1 ? 's' : ''} libre${trip.cupos_disponibles !== 1 ? 's' : ''}`}
              variant={hasSeats ? 'success' : 'outline'}
            />
          </View>

          <Card style={styles.passengersCard}>
            {trip.pasajeros_confirmados.length === 0 ? (
              <Text style={styles.noPassengersText}>
                Aún no hay pasajeros confirmados. ¡Sé el primero en solicitar tu cupo!
              </Text>
            ) : (
              trip.pasajeros_confirmados.map((pasajero) => (
                <View key={pasajero.id} style={styles.passengerRow}>
                  <View style={styles.passengerAvatar}>
                    <Text style={styles.passengerAvatarText}>
                      {pasajero.nombre.slice(0, 2).toUpperCase()}
                    </Text>
                  </View>
                  <View style={styles.passengerInfo}>
                    <Text style={styles.passengerName}>{pasajero.nombre}</Text>
                    <Text style={styles.passengerCareer}>{pasajero.carrera}</Text>
                  </View>
                  <CheckCircle2 size={16} color={COLORS.success} />
                </View>
              ))
            )}
          </Card>
        </View>

        {/* Vehículo y Seguridad */}
        <View style={styles.section}>
          <Card style={styles.vehicleCard}>
            <Car size={24} color={COLORS.navy} style={{ marginRight: 12 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.vehicleTitle}>
                {trip.vehiculo} • Placa {trip.placa}
              </Text>
              <Text style={styles.vehicleNotice}>
                Vehículo y SOAT verificados por la administración universitaria.
              </Text>
            </View>
          </Card>
        </View>

        {/* Botón de Chat con el Conductor */}
        <Button
          title={`Escribir a ${trip.conductor.nombre}`}
          variant="outline"
          icon={<MessageCircle size={18} color={COLORS.navy} />}
          onPress={handleChatPress}
          style={styles.chatButton}
        />

        {/* Botones de Acción Inferiores */}
        <View style={styles.bottomActions}>
          <Button
            title="Pasar"
            variant="outline"
            onPress={() => router.back()}
            style={styles.passBtn}
          />
          <Button
            title={requested ? '¡Cupo Reservado!' : hasSeats ? 'Pedir cupo' : 'Cupos Llenos'}
            variant="yellow"
            disabled={!hasSeats || requested}
            onPress={handleRequestSeat}
            style={styles.requestMainBtn}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.md,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.lg,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    color: COLORS.navy,
    fontWeight: '600',
    marginLeft: 2,
  },
  headerTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    fontWeight: '700',
    color: COLORS.navy,
  },
  heroCard: {
    padding: SPACING.lg,
    borderRadius: RADIUS.card,
    marginBottom: SPACING.xl,
  },
  driverSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  driverAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.primary,
    borderWidth: 2,
    borderColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  driverAvatarText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.lg,
    fontWeight: '700',
    color: COLORS.navy,
  },
  driverInfo: {
    flex: 1,
  },
  driverNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverName: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.lg,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  driverSub: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: '#A3B8D8',
    marginTop: 2,
  },
  tripSummaryBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginVertical: SPACING.sm,
  },
  tripSummaryText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs + 1,
    color: '#FFFFFF',
    lineHeight: 18,
  },
  aporteNotice: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    fontWeight: '700',
    color: COLORS.primary,
    marginTop: 6,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 8,
  },
  tagPill: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: RADIUS.pill,
  },
  tagText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  section: {
    marginBottom: SPACING.xl,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  sectionTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.md,
    fontWeight: '700',
    color: COLORS.navy,
    marginBottom: SPACING.sm,
  },
  stopsCard: {
    padding: SPACING.md,
  },
  stopItem: {
    flexDirection: 'row',
    minHeight: 52,
  },
  stopTimeline: {
    width: 28,
    alignItems: 'center',
  },
  stopDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#94A3B8',
    marginTop: 2,
  },
  stopDotStart: {
    backgroundColor: COLORS.navy,
  },
  stopDotEnd: {
    backgroundColor: COLORS.primary,
    borderWidth: 2,
    borderColor: COLORS.navy,
  },
  stopLine: {
    flex: 1,
    width: 2,
    backgroundColor: '#E2E8F0',
    marginVertical: 4,
  },
  stopContent: {
    flex: 1,
    paddingLeft: 8,
    paddingBottom: 14,
  },
  stopHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  stopName: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    fontWeight: '700',
    color: COLORS.navy,
    flex: 1,
  },
  stopTime: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    fontWeight: '700',
    color: COLORS.support,
    marginLeft: 6,
  },
  stopOrder: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    marginTop: 2,
  },
  passengersCard: {
    padding: SPACING.md,
  },
  noPassengersText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    fontStyle: 'italic',
  },
  passengerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  passengerAvatar: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#EBF1FA',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  passengerAvatarText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    fontWeight: '700',
    color: COLORS.navy,
  },
  passengerInfo: {
    flex: 1,
  },
  passengerName: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    fontWeight: '600',
    color: COLORS.navy,
  },
  passengerCareer: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
  },
  vehicleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.md,
  },
  vehicleTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    fontWeight: '700',
    color: COLORS.navy,
  },
  vehicleNotice: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    marginTop: 2,
  },
  chatButton: {
    marginBottom: SPACING.lg,
  },
  bottomActions: {
    flexDirection: 'row',
    gap: 12,
  },
  passBtn: {
    flex: 1,
  },
  requestMainBtn: {
    flex: 2,
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SPACING.xl,
  },
  errorTitle: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.lg,
    fontWeight: '700',
    color: COLORS.navy,
    marginBottom: SPACING.md,
  },
});
