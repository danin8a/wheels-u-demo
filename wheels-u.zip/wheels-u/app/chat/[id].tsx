import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  ChevronLeft,
  Send,
  MapPin,
  Car,
  Clock,
  ShieldCheck,
  CheckCheck,
} from 'lucide-react-native';
import { WheelsULogo } from '../../src/components/brand/WheelsULogo';
import { Card } from '../../src/components/ui/Card';
import { COLORS, FONTS, RADIUS, SPACING } from '../../src/constants/theme';
import { useChatStore } from '../../src/stores/useChatStore';
import { useTripsStore } from '../../src/stores/useTripsStore';
import { useAuthStore } from '../../src/stores/useAuthStore';
import { Message } from '../../src/types';

const QUICK_REPLIES = [
  'Ya voy en camino 🏃',
  'Llego en 5 min ⏰',
  'Estoy en la parada 📍',
  '¿Dónde van? 👀',
];

export default function ChatScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const tripId = id || 'trip-1';

  const user = useAuthStore((s) => s.user);
  const trip = useTripsStore((s) => s.getTripById(tripId));
  const messages = useChatStore((s) => s.messagesByTrip[tripId] || []);
  const sendMessage = useChatStore((s) => s.sendMessage);
  const sendQuickReply = useChatStore((s) => s.sendQuickReply);
  const sendLocation = useChatStore((s) => s.sendLocation);

  const [inputText, setInputText] = useState('');

  const isDriver = user?.nombre === trip?.conductor.nombre;

  const handleSend = () => {
    if (!inputText.trim()) return;
    sendMessage(
      tripId,
      user?.id || 'usr-current',
      user?.nombre || '[TU NOMBRE]',
      isDriver,
      inputText.trim(),
      'texto'
    );
    setInputText('');
  };

  const handleSendLocation = () => {
    sendLocation(
      tripId,
      user?.id || 'usr-current',
      user?.nombre || '[TU NOMBRE]',
      isDriver,
      4.653,
      -74.083
    );
  };

  const renderMessageItem = ({ item }: { item: Message }) => {
    const isMe = item.autor_id === (user?.id || 'usr-current');
    return (
      <View
        style={[
          styles.msgRow,
          isMe ? styles.myMsgRow : styles.otherMsgRow,
        ]}
      >
        <View
          style={[
            styles.bubble,
            isMe
              ? styles.myBubble
              : item.es_conductor
              ? styles.driverBubble
              : styles.otherBubble,
          ]}
        >
          <View style={styles.bubbleHeader}>
            <Text
              style={[
                styles.authorName,
                isMe ? styles.myAuthor : styles.otherAuthor,
              ]}
            >
              {isMe ? 'Tú' : item.autor_nombre}
            </Text>
            {item.es_conductor && (
              <Text style={styles.driverBadge}>Conductor</Text>
            )}
          </View>

          <Text
            style={[
              styles.msgText,
              isMe ? styles.myMsgText : styles.otherMsgText,
            ]}
          >
            {item.texto}
          </Text>

          <Text
            style={[
              styles.msgTime,
              isMe ? styles.myTime : styles.otherTime,
            ]}
          >
            {item.creado_en}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
      >
        {/* Cabecera del Chat */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => router.back()}
            activeOpacity={0.7}
          >
            <ChevronLeft size={24} color={COLORS.navy} />
          </TouchableOpacity>

          <View style={styles.headerTitleWrap}>
            <Text style={styles.tripRoute}>
              {trip?.origen || '[TU BARRIO]'} → {trip?.destino || '[TU UNIVERSIDAD]'}
            </Text>
            <Text style={styles.tripDriverSub}>
              Conductor: {trip?.conductor.nombre || 'Andrés P.'} • {trip?.hora_salida || '06:30'}
            </Text>
          </View>

          <WheelsULogo size={28} />
        </View>

        {/* Lista de Mensajes */}
        <FlatList
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessageItem}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />

        {/* Píldoras de Respuestas Rápidas (1 toque) */}
        <View style={styles.quickBar}>
          <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            data={QUICK_REPLIES}
            keyExtractor={(item) => item}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.quickPill}
                onPress={() =>
                  sendQuickReply(
                    tripId,
                    user?.id || 'usr-current',
                    user?.nombre || '[TU NOMBRE]',
                    isDriver,
                    item
                  )
                }
                activeOpacity={0.7}
              >
                <Text style={styles.quickPillText}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Barra de Entrada de Texto */}
        <View style={styles.inputContainer}>
          <TouchableOpacity
            style={styles.locationBtn}
            onPress={handleSendLocation}
            activeOpacity={0.7}
          >
            <MapPin size={20} color={COLORS.navy} />
          </TouchableOpacity>

          <TextInput
            style={styles.textInput}
            value={inputText}
            onChangeText={setInputText}
            placeholder="Escribe un mensaje al grupo..."
            placeholderTextColor="#94A3B8"
            multiline={false}
            onSubmitEditing={handleSend}
          />

          <TouchableOpacity
            style={styles.sendBtn}
            onPress={handleSend}
            activeOpacity={0.8}
          >
            <Send size={18} color={COLORS.navy} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  backBtn: {
    padding: 6,
  },
  headerTitleWrap: {
    flex: 1,
    marginLeft: 8,
  },
  tripRoute: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    fontWeight: '700',
    color: COLORS.navy,
  },
  tripDriverSub: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.support,
    marginTop: 1,
  },
  listContent: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  msgRow: {
    marginVertical: 4,
    flexDirection: 'row',
  },
  myMsgRow: {
    justifyContent: 'flex-end',
  },
  otherMsgRow: {
    justifyContent: 'flex-start',
  },
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: RADIUS.lg,
  },
  myBubble: {
    backgroundColor: COLORS.navy,
    borderBottomRightRadius: 4,
  },
  driverBubble: {
    backgroundColor: '#FFF9E5',
    borderWidth: 1.5,
    borderColor: COLORS.primary,
    borderBottomLeftRadius: 4,
  },
  otherBubble: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderBottomLeftRadius: 4,
  },
  bubbleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  authorName: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    fontWeight: '700',
  },
  myAuthor: {
    color: COLORS.primary,
  },
  otherAuthor: {
    color: COLORS.navy,
  },
  driverBadge: {
    fontFamily: FONTS.family,
    fontSize: 9,
    fontWeight: '700',
    color: COLORS.navy,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: RADIUS.pill,
    marginLeft: 6,
  },
  msgText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    lineHeight: 18,
  },
  myMsgText: {
    color: '#FFFFFF',
  },
  otherMsgText: {
    color: COLORS.navy,
  },
  msgTime: {
    fontFamily: FONTS.family,
    fontSize: 10,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  myTime: {
    color: '#A3B8D8',
  },
  otherTime: {
    color: COLORS.support,
  },
  quickBar: {
    backgroundColor: '#F8FAFC',
    paddingVertical: 8,
    paddingHorizontal: SPACING.sm,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  quickPill: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CBD5E1',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
    marginRight: 8,
  },
  quickPillText: {
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.xs,
    color: COLORS.navy,
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  locationBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  textInput: {
    flex: 1,
    fontFamily: FONTS.family,
    fontSize: FONTS.sizes.sm,
    color: COLORS.navy,
    backgroundColor: '#F1F5F9',
    borderRadius: RADIUS.pill,
    paddingHorizontal: 16,
    paddingVertical: 8,
    minHeight: 40,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
});
